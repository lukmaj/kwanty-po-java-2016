package SymulacjaStatku;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.geom.Ellipse2D;

import javax.swing.JComponent;
import javax.swing.Timer;

@SuppressWarnings("serial")
public class GUI extends JComponent
{// P.J.
	
	private final double AU = 1.4960e8; // astronomical units in km
	
	private Planet[] planetModel;
	
	private Ellipse2D[] orbits;
	private Ellipse2D[] planets;
	
	private double scaleFactor=1;
	
	private Timer timeSimulator;
	private double timeScale=1;
	private final int dt=1; // time interval in seconds (s)
	
	public void startTimer()
	{// L.M.
		timeSimulator.start();
	}
	public void stopTimer()
	{// L.M.
		timeSimulator.stop();
	}
	
	public GUI(Planet[] planetModel)
	{
		this.scaleFactor=1.0;
		this.planetModel=planetModel;
		orbits=new Ellipse2D[8];
		planets=new Ellipse2D[8];
		for (int ii=0; ii<8; ii++)
		{
			orbits[ii]=new Ellipse2D.Double();
			planets[ii]=new Ellipse2D.Double();
		}
		
		this.timeScale=1;
		this.timeSimulator=new Timer(1, new ActionListener()
		{// L.M.
			@Override
			public void actionPerformed(ActionEvent arg0)
			{
				for (int ii=0;ii<planetModel.length;++ii)
				{
					planetModel[ii].RK4(dt*timeScale/1000);
					planetModel[0].fullOrbit();
					
				}
				repaint();
			}
		});
	}
	
	
	public void orbitRender() // P.J.
	{// P.J.
		
		double screenHeight=(double)this.getHeight();
		double screenWidth=(double)this.getWidth();
		double screenCenterHeight=screenHeight/2;
		double screenCenterWidth=screenWidth/2;
		
		final int screenMargin=2;
		double screenMaxWidth=2*planetModel[7].getMaxRadius()/AU + screenMargin; // 61 AU on x axis
		double screenMaxHeight=2*planetModel[7].getMinRadius()/AU + screenMargin;
		
		
		double distanceToPixel = screenWidth/screenMaxWidth; // unit: AU
		
		
		for (int ii=0; ii< planetModel.length; ++ii)
		{
 			double pixelMaxRadius = (planetModel[ii].getMaxRadius()/AU)*distanceToPixel*scaleFactor;
			double pixelMinRadius = (planetModel[ii].getMinRadius()/AU)*distanceToPixel*scaleFactor;
			
			double pixelX=(planetModel[ii].getX()/AU)*distanceToPixel*scaleFactor+screenCenterWidth;
			double pixelY=(planetModel[ii].getY()/AU)*distanceToPixel*scaleFactor+screenCenterHeight;
			
			
			orbits[ii].setFrameFromCenter(screenCenterWidth, screenCenterHeight, screenCenterWidth-pixelMaxRadius, screenCenterHeight-pixelMinRadius);
			planets[ii].setFrameFromCenter(pixelX, pixelY, pixelX-2, pixelY-2);
			
			
		}
	}
	
	public void paintComponent(Graphics g)
	{ // P.J.
		Graphics2D g2 = (Graphics2D) g;
		g2.setPaint(Color.RED);
		orbitRender();
		for (int ii=0;ii< orbits.length;++ii)
		{
			g2.draw(orbits[ii]);
			
		}
		
		g2.setPaint(Color.BLACK);
		for (int ii=0;ii<planetModel.length;++ii)
		{
			g2.draw(planets[ii]);
			g2.fill(planets[ii]);
		}
		
	}
	
	public double getScale()
	{ // L.M.
		return scaleFactor;
	}
	
	public void setScale(double newScale)
	{// L.M.
		scaleFactor=newScale;
	}
	
	public double getTimeScale()
	{// L.M.
		return timeScale;
	}
	
	public void setTimeScale(double newTimeModifier)
	{// L.M.
		timeScale=newTimeModifier;
	}
	
	public void printSize()
	{// L.M.
		System.out.println("Height i width" + this.getHeight()+" "+this.getWidth());
	}
	
	
}