package pl.edu.pw.fizyka.pojava.Kwanty;
import javax.swing.JFrame;

public class Main
{
	public static void main(String[] args)
	{
		JFrame game = new MainWindow();
//		game.setVisible(true);
		game.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
	}

}